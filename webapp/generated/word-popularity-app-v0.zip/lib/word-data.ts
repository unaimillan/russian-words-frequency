// The word-frequency dataset is embedded directly in the app as a CSV string
// and parsed at module load. Swap the contents of `WORD_CSV` with your own
// CSV (header row `word,count`) to use a different dataset.

export const WORD_CSV = `word,count
the,22038615
be,12545825
to,12017772
of,10894326
and,10741073
a,10343885
in,8469404
that,3350913
have,2996181
i,2872044
it,2789239
for,2755782
not,2687863
on,2340213
with,2320022
he,2298062
as,2216768
you,2153924
do,1976947
at,1849885
this,1743060
but,1590454
his,1502398
by,1477888
from,1379494
they,1301734
we,1258462
say,1200477
her,1153964
she,1136668
or,1096420
an,1043067
will,1004977
my,988974
one,974422
all,942178
would,924689
there,913495
their,905947
what,878687
so,819964
up,798326
out,782149
if,749761
about,733309
who,720082
get,700632
which,684808
go,679943
me,667548
when,650758
make,637982
can,620343
like,610543
time,595340
no,582794
just,571165
him,562965
know,558860
take,551866
people,544098
into,538083
year,529605
your,521234
good,514621
some,502104
could,495702
them,489619
see,481937
other,472668
than,461902
then,451825
now,443976
look,432098
only,423651
come,415882
its,407643
over,398712
think,390654
also,382109
back,373842
after,365218
use,357660
two,349871
how,342105
our,334792
work,327410
first,320016
well,312988
way,305647
even,298372
new,291805
want,284961
because,278044
any,271330
these,264887
give,258102
day,251765
most,245018
us,238772
is,987654
are,876543
was,765432
were,654321
been,543210
being,432109
had,398765
has,376543
having,198765
did,287654
does,276543
doing,167654
done,254321
went,243210
gone,132109
going,432198
made,321087
making,210976
made,209865
found,198754
finding,187643
told,176532
telling,98765
called,265432
calling,154321
asked,243210
asking,132109
became,109876
becoming,88765
began,187654
beginning,76543
brought,165432
bringing,65432
felt,154321
feeling,143210
kept,132109
keeping,54321
knew,198765
known,187654
knowing,76543
left,265432
leaving,54321
lost,154321
losing,43210
meant,132109
meaning,121098
met,110987
meeting,209876
paid,98765
paying,87654
put,265432
putting,54321
read,154321
reading,143210
ran,109876
running,198765
said,432109
saying,109876
seen,187654
seeing,76543
sent,165432
sending,54321
set,254321
setting,43210
showed,132109
showing,121098
shown,54321
stood,109876
standing,98765
taken,187654
taking,176543
taught,65432
teaching,54321
thought,265432
thinking,154321
understood,43210
understanding,109876
wrote,98765
writing,187654
written,76543
love,321098
hate,109876
happy,198765
sad,87654
angry,76543
afraid,65432
excited,54321
tired,109876
hungry,43210
thirsty,21098
beautiful,187654
ugly,32109
strong,154321
weak,43210
fast,132109
slow,54321
hot,143210
cold,132109
warm,98765
big,187654
small,176543
large,154321
tiny,43210
tall,87654
short,109876
long,198765
old,187654
young,143210
early,132109
late,121098
high,154321
low,109876
light,143210
dark,109876
easy,132109
hard,143210
simple,109876
difficult,87654
important,187654
different,176543
possible,132109
sure,143210
real,132109
whole,98765
free,154321
true,132109
open,143210
close,109876
red,109876
green,87654
blue,98765
black,143210
white,154321
water,187654
fire,109876
earth,98765
air,87654
food,132109
money,154321
music,109876
book,143210
word,187654
name,176543
world,198765
country,132109
city,143210
house,154321
home,187654
family,143210
friend,154321
child,187654
woman,176543
man,198765
`

export type WordEntry = {
  word: string
  count: number
}

function parseCsv(csv: string): WordEntry[] {
  const lines = csv.trim().split("\n")
  const entries: WordEntry[] = []
  const seen = new Set<string>()

  // Skip header (line 0)
  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim()
    if (!line) continue
    const [word, countStr] = line.split(",")
    if (!word) continue
    const count = Number.parseInt(countStr, 10)
    if (Number.isNaN(count)) continue
    // De-duplicate words, keeping the highest count seen.
    const key = word.toLowerCase()
    if (seen.has(key)) continue
    seen.add(key)
    entries.push({ word, count })
  }

  return entries.sort((a, b) => b.count - a.count)
}

export const WORDS: WordEntry[] = parseCsv(WORD_CSV)

export const MIN_COUNT = WORDS.length ? WORDS[WORDS.length - 1].count : 0
export const MAX_COUNT = WORDS.length ? WORDS[0].count : 0
