import { WordExplorer } from "@/components/word-explorer"

export default function Page() {
  return (
    <main className="min-h-dvh bg-background text-foreground">
      <WordExplorer />
    </main>
  )
}
