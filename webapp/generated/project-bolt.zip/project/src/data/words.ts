// Generate 100k word entries programmatically
const baseWords = [
  "the", "be", "to", "of", "and", "a", "in", "that", "have", "i",
  "it", "for", "not", "on", "with", "he", "as", "you", "do", "at",
  "this", "but", "his", "by", "from", "they", "we", "say", "her", "she",
  "or", "an", "will", "my", "one", "all", "would", "there", "their", "what",
  "so", "up", "out", "if", "about", "who", "get", "which", "go", "me",
  "when", "make", "can", "like", "time", "no", "just", "him", "know", "take",
  "people", "into", "year", "your", "good", "some", "could", "them", "see", "other",
  "than", "then", "now", "look", "only", "come", "its", "over", "think", "also",
  "back", "after", "use", "two", "how", "our", "work", "first", "well", "way",
  "even", "new", "want", "because", "any", "these", "give", "day", "most", "us",
  "world", "very", "through", "just", "form", "much", "great", "where", "need", "help",
  "try", "ask", "find", "place", "old", "while", "mean", "keep", "let", "begin",
  "seem", "talk", "turn", "start", "might", "show", "hear", "play", "run", "move",
  "live", "believe", "hold", "bring", "happen", "write", "provide", "sit", "stand", "lose",
  "pay", "meet", "include", "continue", "set", "learn", "change", "lead", "understand", "watch",
  "follow", "stop", "create", "speak", "read", "allow", "add", "spend", "grow", "open",
  "walk", "win", "offer", "remember", "love", "consider", "appear", "buy", "wait", "serve",
  "die", "send", "expect", "build", "stay", "fall", "cut", "reach", "kill", "remain",
  "suggest", "raise", "pass", "sell", "require", "report", "decide", "pull", "develop", "feel",
  "food", "city", "community", "name", "team", "area", "money", "business", "issue", "side",
  "kind", "education", "program", "question", "government", "company", "number", "night", "point", "home",
  "water", "room", "mother", "member", "power", "hour", "game", "line", "end", "member",
  "child", "eye", "head", "car", "face", "door", "hand", "part", "local", "law",
  "book", "office", "door", "word", "business", "issue", "side", "week", "case", "problem",
  "fact", "state", "family", "student", "group", "country", "plan", "result", "school", "study",
  "health", "person", "art", "war", "history", "party", "voice", "reason", "service", "friend",
  "idea", "body", "information", "level", "office", "design", "door", "word", "public", "control",
  "girl", "guy", "job", "mind", "report", "light", "parent", "mother", "father", "child",
  "man", "woman", "boy", "girl", "child", "children", "people", "person", "human", "being",
  "house", "home", "building", "apartment", "room", "wall", "floor", "window", "door", "roof"
];

const suffixes = ["", "ing", "ed", "er", "est", "ly", "ness", "ment", "tion", "s"];
const prefixes = ["", "un", "re", "pre", "dis", "mis", "over", "under", "out", "sub"];

function seededRandom(seed: number): number {
  const x = Math.sin(seed++) * 10000;
  return x - Math.floor(x);
}

export interface WordEntry {
  word: string;
  count: number;
}

const wordMap = new Map<string, number>();
let seed = 12345;

// Generate unique words with variations
for (let i = 0; i < 100000; i++) {
  const baseIndex = Math.floor(seededRandom(seed++) * baseWords.length);
  const prefixIndex = Math.floor(seededRandom(seed++) * prefixes.length);
  const suffixIndex = Math.floor(seededRandom(seed++) * suffixes.length);

  const base = baseWords[baseIndex];
  const prefix = prefixes[prefixIndex];
  const suffix = suffixes[suffixIndex];

  let word = prefix + base + suffix;

  // Add some variation to avoid duplicates
  if (seededRandom(seed++) > 0.7) {
    const variation = Math.floor(seededRandom(seed++) * 100);
    if (variation > 0) {
      word += variation.toString();
    }
  }

  // Generate count (some words are more popular)
  const baseCount = Math.floor(seededRandom(seed++) * 50000) + 100;
  const multiplier = seededRandom(seed++) > 0.9 ? 10 : 1;
  const count = Math.min(baseCount * multiplier, 500000);

  // Only add if unique
  if (!wordMap.has(word)) {
    wordMap.set(word, count);
  }
}

// Convert to array and sort by count descending
export const wordData: WordEntry[] = Array.from(wordMap.entries())
  .map(([word, count]) => ({ word, count }))
  .sort((a, b) => b.count - a.count);

// Pre-compute min/max for range slider
export const minCount = Math.min(...wordData.map(w => w.count));
export const maxCount = Math.max(...wordData.map(w => w.count));
export const totalWords = wordData.length;
