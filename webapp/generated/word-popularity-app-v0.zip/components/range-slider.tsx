"use client"

import type React from "react"

import { useCallback, useRef } from "react"

type RangeSliderProps = {
  min: number
  max: number
  low: number
  high: number
  onChange: (low: number, high: number) => void
}

function formatNumber(n: number) {
  return n.toLocaleString("en-US")
}

export function RangeSlider({ min, max, low, high, onChange }: RangeSliderProps) {
  const trackRef = useRef<HTMLDivElement>(null)
  const dragging = useRef<"low" | "high" | null>(null)

  const range = Math.max(1, max - min)
  const lowPct = ((low - min) / range) * 100
  const highPct = ((high - min) / range) * 100

  const valueFromClientX = useCallback(
    (clientX: number) => {
      const track = trackRef.current
      if (!track) return min
      const rect = track.getBoundingClientRect()
      const ratio = Math.min(1, Math.max(0, (clientX - rect.left) / rect.width))
      return Math.round(min + ratio * range)
    },
    [min, range],
  )

  const handlePointerMove = useCallback(
    (e: PointerEvent) => {
      if (!dragging.current) return
      const value = valueFromClientX(e.clientX)
      if (dragging.current === "low") {
        onChange(Math.min(value, high), high)
      } else {
        onChange(low, Math.max(value, low))
      }
    },
    [valueFromClientX, low, high, onChange],
  )

  const stopDragging = useCallback(() => {
    dragging.current = null
    window.removeEventListener("pointermove", handlePointerMove)
    window.removeEventListener("pointerup", stopDragging)
  }, [handlePointerMove])

  const startDragging = useCallback(
    (handle: "low" | "high") => (e: React.PointerEvent) => {
      e.preventDefault()
      dragging.current = handle
      window.addEventListener("pointermove", handlePointerMove)
      window.addEventListener("pointerup", stopDragging)
    },
    [handlePointerMove, stopDragging],
  )

  const commitLow = (raw: string) => {
    const parsed = Number.parseInt(raw.replace(/[^0-9]/g, ""), 10)
    if (Number.isNaN(parsed)) return
    onChange(Math.min(Math.max(parsed, min), high), high)
  }

  const commitHigh = (raw: string) => {
    const parsed = Number.parseInt(raw.replace(/[^0-9]/g, ""), 10)
    if (Number.isNaN(parsed)) return
    onChange(low, Math.max(Math.min(parsed, max), low))
  }

  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center justify-between gap-3">
        <label className="flex flex-1 flex-col gap-1">
          <span className="text-[11px] uppercase tracking-wide text-muted-foreground">Min</span>
          <input
            inputMode="numeric"
            value={formatNumber(low)}
            onChange={(e) => commitLow(e.target.value)}
            className="w-full rounded-md border border-border bg-card px-2 py-1.5 font-mono text-sm tabular-nums outline-none focus:ring-2 focus:ring-ring"
            aria-label="Minimum count"
          />
        </label>
        <label className="flex flex-1 flex-col gap-1">
          <span className="text-[11px] uppercase tracking-wide text-muted-foreground">Max</span>
          <input
            inputMode="numeric"
            value={formatNumber(high)}
            onChange={(e) => commitHigh(e.target.value)}
            className="w-full rounded-md border border-border bg-card px-2 py-1.5 font-mono text-sm tabular-nums outline-none focus:ring-2 focus:ring-ring"
            aria-label="Maximum count"
          />
        </label>
      </div>

      <div ref={trackRef} className="relative h-6 select-none">
        {/* base track */}
        <div className="absolute top-1/2 h-1 w-full -translate-y-1/2 rounded-full bg-muted" />
        {/* active range */}
        <div
          className="absolute top-1/2 h-1 -translate-y-1/2 rounded-full bg-primary"
          style={{ left: `${lowPct}%`, right: `${100 - highPct}%` }}
        />
        {/* low handle */}
        <button
          type="button"
          onPointerDown={startDragging("low")}
          className="absolute top-1/2 size-4 -translate-x-1/2 -translate-y-1/2 cursor-grab rounded-full border-2 border-primary bg-background shadow-sm outline-none focus:ring-2 focus:ring-ring active:cursor-grabbing"
          style={{ left: `${lowPct}%` }}
          role="slider"
          aria-label="Minimum count handle"
          aria-valuemin={min}
          aria-valuemax={high}
          aria-valuenow={low}
        />
        {/* high handle */}
        <button
          type="button"
          onPointerDown={startDragging("high")}
          className="absolute top-1/2 size-4 -translate-x-1/2 -translate-y-1/2 cursor-grab rounded-full border-2 border-primary bg-background shadow-sm outline-none focus:ring-2 focus:ring-ring active:cursor-grabbing"
          style={{ left: `${highPct}%` }}
          role="slider"
          aria-label="Maximum count handle"
          aria-valuemin={low}
          aria-valuemax={max}
          aria-valuenow={high}
        />
      </div>
    </div>
  )
}
