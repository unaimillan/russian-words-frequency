"use client"

import { useMemo, useState } from "react"
import { Search, Regex, Type, AlertCircle } from "lucide-react"
import { RangeSlider } from "@/components/range-slider"
import { WORDS, MIN_COUNT, MAX_COUNT } from "@/lib/word-data"

type SearchMode = "direct" | "regex"

const LIMIT_OPTIONS = [10, 20, 50, 100, 1000, "all"] as const
type LimitOption = (typeof LIMIT_OPTIONS)[number]

export function WordExplorer() {
  const [query, setQuery] = useState("")
  const [mode, setMode] = useState<SearchMode>("direct")
  const [low, setLow] = useState(MIN_COUNT)
  const [high, setHigh] = useState(MAX_COUNT)
  const [limit, setLimit] = useState<LimitOption>(50)

  // Compile the regex when in regex mode; track whether it's valid.
  const { matcher, regexError } = useMemo(() => {
    if (!query) {
      return { matcher: null as ((w: string) => boolean) | null, regexError: null as string | null }
    }
    if (mode === "regex") {
      try {
        const re = new RegExp(query, "i")
        return { matcher: (w: string) => re.test(w), regexError: null }
      } catch (err) {
        return { matcher: null, regexError: (err as Error).message }
      }
    }
    const needle = query.toLowerCase()
    return { matcher: (w: string) => w.toLowerCase().includes(needle), regexError: null }
  }, [query, mode])

  const results = useMemo(() => {
    return WORDS.filter((entry) => {
      if (entry.count < low || entry.count > high) return false
      if (matcher && !matcher(entry.word)) return false
      return true
    })
  }, [matcher, low, high])

  const displayed = useMemo(() => {
    return limit === "all" ? results : results.slice(0, limit)
  }, [results, limit])

  return (
    <div className="mx-auto flex h-dvh w-full max-w-2xl flex-col px-4">
      {/* Header */}
      <header className="flex items-center justify-between gap-4 pb-3 pt-6">
        <h1 className="text-lg font-semibold tracking-tight">Word Popularity</h1>
        <div className="flex items-center gap-3">
          <label htmlFor="limit" className="text-xs text-muted-foreground">
            Show
          </label>
          <select
            id="limit"
            value={String(limit)}
            onChange={(e) => setLimit(e.target.value === "all" ? "all" : (Number(e.target.value) as LimitOption))}
            className="rounded-lg border border-border bg-card px-2 py-1 text-xs font-medium outline-none focus:ring-2 focus:ring-ring"
          >
            {LIMIT_OPTIONS.map((opt) => (
              <option key={String(opt)} value={String(opt)}>
                {opt === "all" ? "All" : opt.toLocaleString("en-US")}
              </option>
            ))}
          </select>
          <span className="font-mono text-xs tabular-nums text-muted-foreground">
            {displayed.length.toLocaleString("en-US")} / {results.length.toLocaleString("en-US")}
          </span>
        </div>
      </header>

      {/* Range controls */}
      <div className="border-y border-border py-4">
        <RangeSlider
          min={MIN_COUNT}
          max={MAX_COUNT}
          low={low}
          high={high}
          onChange={(l, h) => {
            setLow(l)
            setHigh(h)
          }}
        />
      </div>

      {/* Results table */}
      <div className="min-h-0 flex-1 overflow-y-auto">
        {displayed.length === 0 ? (
          <p className="py-16 text-center text-sm text-muted-foreground">No words match your filters.</p>
        ) : (
          <table className="w-full border-collapse">
            <thead className="sticky top-0 bg-background">
              <tr className="border-b border-border text-left text-[11px] uppercase tracking-wide text-muted-foreground">
                <th className="py-2 font-medium">Word</th>
                <th className="py-2 text-right font-medium">Mentions</th>
              </tr>
            </thead>
            <tbody>
              {displayed.map((entry) => (
                <tr key={entry.word} className="border-b border-border/60 last:border-0">
                  <td className="py-2 font-mono text-sm">{entry.word}</td>
                  <td className="py-2 text-right font-mono text-sm tabular-nums text-muted-foreground">
                    {entry.count.toLocaleString("en-US")}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Bottom search bar */}
      <div className="pb-6 pt-3">
        {regexError && (
          <div className="mb-2 flex items-center gap-1.5 text-xs text-destructive">
            <AlertCircle className="size-3.5 shrink-0" />
            <span className="truncate">Invalid regex: {regexError}</span>
          </div>
        )}
        <div className="flex items-center gap-2 rounded-xl border border-border bg-card p-1.5 shadow-sm focus-within:ring-2 focus-within:ring-ring">
          <Search className="ml-1.5 size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={mode === "regex" ? "Search with regex, e.g. ^th|ing$" : "Search words..."}
            className="min-w-0 flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground"
            aria-label="Search words"
            spellCheck={false}
            autoCapitalize="off"
            autoCorrect="off"
          />
          <button
            type="button"
            onClick={() => setMode(mode === "direct" ? "regex" : "direct")}
            className="flex shrink-0 items-center gap-1.5 rounded-lg bg-secondary px-2.5 py-1.5 text-xs font-medium text-secondary-foreground transition-colors hover:bg-muted"
            aria-pressed={mode === "regex"}
            title={mode === "direct" ? "Switch to regex search" : "Switch to direct search"}
          >
            {mode === "direct" ? (
              <>
                <Type className="size-3.5" aria-hidden="true" />
                Direct
              </>
            ) : (
              <>
                <Regex className="size-3.5" aria-hidden="true" />
                Regex
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  )
}
